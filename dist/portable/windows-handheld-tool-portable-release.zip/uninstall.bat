@echo off
setlocal enabledelayedexpansion
title Windows Handheld Tool - Go bo va Don dep sach se

:: 1. Kiem tra quyen Administrator (UAC Elevation)
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Dang yeu cau quyen Administrator de go bo ung dung va tac vu he thong...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c \"\"%~f0\" %*\"' -Verb RunAs"
    exit /b
)

:: Neu co tham so %1 truyen vao, tuc la dang chay tu thu muc %TEMP% de xoa thu muc dich
if not "%~1"=="" goto :RUN_FROM_TEMP

:: 2. Dang chay truc tiep tu thu muc ung dung Portable
echo ========================================================
echo   Windows Handheld Tool - Go bo va Don dep sach se
echo ========================================================
echo.
echo Thu muc ung dung: %~dp0
echo.
echo Canh bao: Thao tac nay se:
echo   1. Tat toan bo tien trinh dang chay cua ung dung.
echo   2. Xoa bo tac vu tu khoi dong cung Windows (Task Scheduler).
echo   3. XOA VINH VIEN toan bo thu muc ung dung nay khoi o dia.
echo.
set /p "CONFIRM=Ban co chac chan muon tiep tuc khong? (Y/N, mac dinh N): "
if /i not "!CONFIRM!"=="Y" (
    echo [*] Da huy thao tac go bo.
    timeout /t 2 >nul
    exit /b 0
)

:: Sao chep kich ban nay sang thu muc tam %TEMP% de tranh bi khoa thu muc lam viec
set "TEMP_SCRIPT=%TEMP%\handheld_tool_cleanup_%RANDOM%.bat"
set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"

copy /y "%~f0" "%TEMP_SCRIPT%" >nul

echo.
echo [*] Dang chuyen quyen dieu khien sang tien trinh doc lap de don dep...
start "" cmd.exe /c ""%TEMP_SCRIPT%" "%APP_DIR%""
exit /b 0

:: =========================================================================
:RUN_FROM_TEMP
:: Phan doan chay doc lap tu %TEMP%
cd /d "%TEMP%"
set "TARGET_DIR=%~1"

echo ========================================================
echo   Dang tien hanh go bo va don dep sach se...
echo ========================================================
echo.

:: 1. Cuong buc ket thuc tien trinh chinh va cay tien trinh con
echo [*] Dang tat tien trinh windows_handheld_tool.exe...
taskkill /F /IM "windows_handheld_tool.exe" /T >nul 2>&1

:: 2. Xoa tac vu tu khoi dong cung Windows trong Task Scheduler
echo [*] Dang xoa tac vu khoi dong WindowsHandheldTool_AutoStart...
schtasks /delete /tn "WindowsHandheldTool_AutoStart" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "HandheldQuickSettings" /f >nul 2>&1

:: 3. Cho 2 giay de nhan Windows thu hoi toan bo File Handle va DLL
echo [*] Dang giai phong tai nguyen bo nho RAM va o dia...
timeout /t 2 /nobreak >nul

:: 4. Xoa sach thu muc Portable dich
echo [*] Dang xoa thu muc ung dung: "%TARGET_DIR%"...
set /a ATTEMPTS=0
:RETRY_DELETE
rmdir /S /Q "%TARGET_DIR%" >nul 2>&1
if exist "%TARGET_DIR%" (
    set /a ATTEMPTS+=1
    if !ATTEMPTS! leq 3 (
        timeout /t 1 /nobreak >nul
        goto :RETRY_DELETE
    )
)

echo.
if not exist "%TARGET_DIR%" (
    echo ========================================================
    echo   [THANH CONG] Da go bo sach se va xoa thu muc thanh cong!
    echo ========================================================
) else (
    echo ========================================================
    echo   [LUU Y] Mot so tap tin van dang bi khoa boi tien trinh khac.
    echo   Vui long khoi dong lai may va xoa thu muc thu cong.
    echo ========================================================
)

echo.
timeout /t 3 >nul

:: 5. Tu huy tep tam trong %TEMP%
(goto) 2>nul & del "%~f0" & exit
